function setLevel(state){
    localStorage.setItem('state', state);
}